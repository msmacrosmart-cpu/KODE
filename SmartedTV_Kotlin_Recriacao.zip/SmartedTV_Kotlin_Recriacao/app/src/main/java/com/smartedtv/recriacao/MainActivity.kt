package com.smartedtv.recriacao

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = (
            android.view.View.SYSTEM_UI_FLAG_FULLSCREEN
                or android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or android.view.View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or android.view.View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            )
        setContent { SmartedHomeScreen() }
    }
}

private data class NavEntry(val label: String, val icon: ImageVector)

@Composable
private fun SmartedHomeScreen() {
    val entries = listOf(
        NavEntry("Canais", Icons.Default.LiveTv),
        NavEntry("Filmes", Icons.Default.Movie),
        NavEntry("Séries", Icons.Default.LocalMovies),
        NavEntry("Navegar", Icons.Default.QueryStats)
    )
    var selected by remember { mutableIntStateOf(0) }
    var now by remember { mutableStateOf(Date()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = Date()
            kotlinx.coroutines.delay(30_000)
        }
    }
    val locale = Locale("pt", "BR")
    val time = SimpleDateFormat("HH:mm", locale).format(now)
    val date = SimpleDateFormat("EEEE, d 'de' MMMM", locale).format(now)
        .replaceFirstChar { if (it.isLowerCase()) it.titlecase(locale) else it.toString() }

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.linearGradient(
                    listOf(Color(0xFF252525), Color(0xFF080808), Color(0xFF030303))
                )
            )
    ) {
        // The reference is a 1536 x 864 landscape composition.
        val sx = maxWidth / 1536f
        val sy = maxHeight / 864f
        fun x(v: Float): Dp = sx * v
        fun y(v: Float): Dp = sy * v
        fun fs(v: Float): TextUnit = (sx.value * v).sp

        // Subtle diagonal graphite panels in the matte-black background.
        Box(
            Modifier.offset(x(0f), y(0f)).size(x(1536f), y(864f))
                .background(
                    Brush.linearGradient(
                        0f to Color(0xFF252525),
                        0.38f to Color(0xFF111111),
                        1f to Color(0xFF030303)
                    )
                )
        )
        Box(
            Modifier.offset(x(555f), y(-100f)).size(x(300f), y(550f))
                .background(Color(0x16000000))
        )

        // Main white content canvas, deliberately left empty like the supplied reference.
        Box(
            Modifier.offset(x(190f), y(107f))
                .size(x(1346f), y(757f))
                .shadow(18.dp, RoundedCornerShape(topStart = 58.dp))
                .clip(RoundedCornerShape(topStart = 58.dp))
                .background(Color(0xFFFEFEFE))
        )
        // Lower white extension with the large rounded upper-left corner.
        Box(
            Modifier.offset(x(57f), y(700f))
                .size(x(1479f), y(164f))
                .clip(RoundedCornerShape(topStart = 62.dp))
                .background(Color.White)
        )

        // Brand capsule.
        Capsule(
            modifier = Modifier.offset(x(221f), y(12f)).size(x(287f), y(76f)),
            radius = 50.dp
        ) {
            Text(
                "Smarted-TV",
                color = Color(0xFFF7F7F7),
                fontSize = fs(37f),
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )
        }

        // Clock and date capsule.
        Capsule(
            modifier = Modifier.offset(x(890f), y(12f)).size(x(535f), y(76f)),
            radius = 50.dp
        ) {
            Row(
                Modifier.fillMaxSize().padding(horizontal = x(31f)),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Text(time, color = Color.White, fontSize = fs(38f), fontWeight = FontWeight.Bold)
                Spacer(Modifier.width(x(23f)))
                Box(Modifier.width(1.dp).height(y(38f)).background(Color(0xFF777777)))
                Spacer(Modifier.width(x(23f)))
                Text(
                    date,
                    color = Color(0xFFF0F0F0),
                    fontSize = fs(22f),
                    fontWeight = FontWeight.Medium,
                    maxLines = 1
                )
            }
        }

        // Raised outer navigation rail.
        Box(
            Modifier.offset(x(23f), y(52f))
                .size(x(167f), y(648f))
                .shadow(18.dp, RoundedCornerShape(48.dp))
                .clip(RoundedCornerShape(48.dp))
                .background(
                    Brush.verticalGradient(
                        listOf(Color(0xFF282828), Color(0xFF111111), Color(0xFF030303))
                    )
                )
                .border(1.dp, Color(0xFF454545), RoundedCornerShape(48.dp))
        )

        Column(
            modifier = Modifier.offset(x(37f), y(87f)).width(x(122f)),
            verticalArrangement = Arrangement.spacedBy(y(22f))
        ) {
            entries.forEachIndexed { index, item ->
                NavigationTile(
                    entry = item,
                    selected = selected == index,
                    modifier = Modifier.size(x(122f), y(132f)),
                    iconSize = fs(43f),
                    labelSize = fs(23f),
                    onClick = { selected = index }
                )
            }
        }
    }
}

@Composable
private fun Capsule(
    modifier: Modifier,
    radius: Dp,
    content: @Composable BoxScope.() -> Unit
) {
    Box(
        modifier
            .shadow(8.dp, RoundedCornerShape(radius))
            .clip(RoundedCornerShape(radius))
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFF202020), Color(0xFF080808))
                )
            )
            .border(1.5.dp, Color(0xFF555555), RoundedCornerShape(radius)),
        contentAlignment = Alignment.Center,
        content = content
    )
}

@Composable
private fun NavigationTile(
    entry: NavEntry,
    selected: Boolean,
    modifier: Modifier,
    iconSize: TextUnit,
    labelSize: TextUnit,
    onClick: () -> Unit
) {
    val fill = if (selected) {
        Brush.verticalGradient(listOf(Color(0xFF333333), Color(0xFF171717)))
    } else {
        Brush.verticalGradient(listOf(Color(0xFF242424), Color(0xFF101010)))
    }
    Box(
        modifier = modifier
            .shadow(if (selected) 9.dp else 5.dp, RoundedCornerShape(32.dp))
            .clip(RoundedCornerShape(32.dp))
            .background(fill)
            .border(1.5.dp, Color(0xFF4B4B4B), RoundedCornerShape(32.dp))
            .focusable(),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = entry.icon,
                contentDescription = entry.label,
                tint = Color.White,
                modifier = Modifier.size(iconSize.value.dp)
            )
            Spacer(Modifier.height(9.dp))
            Text(
                entry.label,
                color = Color.White,
                fontSize = labelSize,
                fontWeight = FontWeight.SemiBold,
                textAlign = TextAlign.Center,
                maxLines = 1
            )
        }
    }
}
