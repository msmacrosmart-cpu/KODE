# Smarted-TV — recriação da tela em Kotlin

Projeto Android nativo em Kotlin + Jetpack Compose, preparado para orientação horizontal e tela cheia.

## O que foi recriado
- Fundo preto/grafite com acabamento matte.
- Cápsula superior com a marca Smarted-TV.
- Cápsula superior direita com relógio e data em português (atualizados automaticamente).
- Barra lateral com quatro opções e ícones brancos.
- Painel principal branco com cantos arredondados, mantendo o espaço vazio da referência.

## Abrir e gerar APK
1. Extraia o ZIP.
2. Abra a pasta `SmartedTV_Kotlin_Recriacao` no Android Studio.
3. Aguarde a sincronização do Gradle.
4. Execute `:app:assembleDebug`.

O APK de depuração será gerado em `app/build/outputs/apk/debug/app-debug.apk`.

## Observação
Este pacote recria a composição visual da imagem enviada. Os destinos das opções da barra lateral ainda não foram conectados às telas/conteúdos reais do aplicativo.
